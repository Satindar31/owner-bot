const Discord = require('discord.js');

const client = new Discord.Client();



client.once('ready', () => {
    console.log('owner is online!')
});

client.login('Nzg3OTUzODU2MTQ3NDg4Nzc4.X9cdNg.joZtTJlf92fVv5l0eTkXBDxk5hA');
